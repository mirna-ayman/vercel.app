export const msg = `Hey guys, I found a cool project!
Check out Free-Hit🏏, an open-source App for discovering free and helpful tools that cater to our needs
It's a one-stop solution for finding amazing resources
Don't forget to give it a⭐️and explore it on GitHub 
https://github.com/JasonDsouza212/free-hit`
