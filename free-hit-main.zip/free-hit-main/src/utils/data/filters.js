export const allFilters = [
  'all',
  'remote',
  'resume',
  'ai',
  'ethical',
  'movies',
  'extensions',
  'ui',
  'web',
  'coding',
  'courses',
  'tools',
  'image_generation',
  'api',
  'esports'
]
